import { useState } from "react";

const NAV = [
  { id: "accueil", label: "Accueil", icon: "🏠", sub: [] },
  {
    id: "cannes", label: "Cannes", icon: "🎣",
    sub: [
      { id: "cannes-bateau", label: "Cannes Bateau" },
      { id: "cannes-bord", label: "Cannes Bord de Mer" },
    ]
  },
  {
    id: "moulinets", label: "Moulinets", icon: "⚙️",
    sub: [
      { id: "moulinet-spinning", label: "Moulinet Spinning" },
      { id: "moulinet-casting", label: "Moulinet Casting" },
    ]
  },
  {
    id: "lignes", label: "Lignes de Pêche", icon: "🧵",
    sub: [
      { id: "ligne-tresse", label: "Tresse" },
      { id: "ligne-nylon", label: "Nylon" },
      { id: "ligne-bas", label: "Bas de Ligne" },
    ]
  },
  {
    id: "leurres", label: "Leurres", icon: "🐟",
    sub: [
      { id: "leurre-souple", label: "Leurres Souples" },
      { id: "leurre-traine", label: "Leurres Traîne" },
      { id: "leurre-biggame", label: "Leurres Big Game" },
      { id: "leurre-dur", label: "Leurres Durs" },
    ]
  },
  {
    id: "accessoires", label: "Accessoires", icon: "🧰",
    sub: [
      { id: "acc-hamecons", label: "Hameçons & Plombs" },
      { id: "acc-vetements", label: "Vêtements Mer" },
      { id: "acc-outillage", label: "Outillage" },
      { id: "acc-glacieres", label: "Glacières & Viviers" },
    ]
  },
  {
    id: "bateaux", label: "Bateaux & Navigation", icon: "⛵",
    sub: [
      { id: "bat-gps", label: "GPS & Sondeurs" },
      { id: "bat-ancres", label: "Ancres & Mouillages" },
      { id: "bat-securite", label: "Sécurité Mer" },
    ]
  },
];

const PRODUCTS = {
  "cannes-bateau": [
    { id: 1, name: "Canne Bateau Jigging Pro 180", price: 189.90, desc: "1.80m · PE4-8 · Bague SiC Fuji · Puissance 200-400g", badge: "Bestseller", emoji: "🎣", stock: 8 },
    { id: 2, name: "Canne Drift Ocean Master", price: 134.50, desc: "2.10m · Action parabolique · Anneau ALPS · 80-200g", badge: "Nouveau", emoji: "🎣", stock: 5 },
    { id: 3, name: "Canne Big Game Tuna 50lb", price: 289.00, desc: "1.65m · Classe 50 · Carbone haute modulus · Porte moulinet roller", badge: null, emoji: "🎣", stock: 3 },
    { id: 4, name: "Canne Palangrotte Mer 2m", price: 69.90, desc: "2m · Fibre de verre · Multi-pièces · Puissance 200g", badge: "Promo", emoji: "🎣", stock: 15 },
  ],
  "cannes-bord": [
    { id: 5, name: "Canne Surfcasting 4.20m Xtrem", price: 149.90, desc: "4.20m · Carbone T40 · 100-200g · Anneau K-Guide", badge: "Bestseller", emoji: "🎣", stock: 6 },
    { id: 6, name: "Canne Rockfishing Shore 2.70m", price: 119.00, desc: "2.70m · Ultra-légère 118g · 10-40g · Ringing Fuji", badge: null, emoji: "🎣", stock: 10 },
    { id: 7, name: "Canne Shore Jigging 3m", price: 175.00, desc: "3m · PE1-4 · Action fast · 40-150g", badge: "Nouveau", emoji: "🎣", stock: 4 },
    { id: 8, name: "Canne Lancer Léger Mer 2.40m", price: 89.90, desc: "2.40m · 20-80g · Carbon composite · Léger et sensible", badge: null, emoji: "🎣", stock: 12 },
  ],
  "moulinet-spinning": [
    { id: 9, name: "Moulinet Spinning Daiwa BG 5000", price: 159.00, desc: "Taille 5000 · 6+1 roulements · Frein 12kg · IPX6", badge: "Bestseller", emoji: "⚙️", stock: 9 },
    { id: 10, name: "Spinning Shimano Stradic 8000", price: 229.00, desc: "Taille 8000 · 6BB · Frein avant 14kg · Micromodule II", badge: null, emoji: "⚙️", stock: 5 },
    { id: 11, name: "Penn Battle III 6000", price: 109.90, desc: "Taille 6000 · Full métal · 5+1 roulements · HT-100", badge: "Promo", emoji: "⚙️", stock: 14 },
  ],
  "moulinet-casting": [
    { id: 12, name: "Moulinet Casting Abu Garcia 7000", price: 199.00, desc: "Récupération 82cm · 5+1 BB · Frein magnétique · 385g", badge: "Nouveau", emoji: "⚙️", stock: 4 },
    { id: 13, name: "Casting Shimano Torium 20HGA", price: 249.00, desc: "Rapport 6.3:1 · Frein 14kg · Corps aluminium · HG série", badge: null, emoji: "⚙️", stock: 3 },
    { id: 14, name: "Penn Fathom 40N Level Wind", price: 189.00, desc: "Taille 40N · CCA aluminium · Frein 27kg · HT-100", badge: "Bestseller", emoji: "⚙️", stock: 7 },
  ],
  "ligne-tresse": [
    { id: 15, name: "Tresse Daiwa J-Braid x8 300m", price: 44.90, desc: "0.24mm · 22kg · 8 brins · Multicouleur 10m", badge: "Bestseller", emoji: "🧵", stock: 25 },
    { id: 16, name: "Tresse Shimano Kairiki 8 300m", price: 39.90, desc: "0.20mm · 18kg · 8 brins · Acier gris", badge: null, emoji: "🧵", stock: 18 },
    { id: 17, name: "Tresse Sufix 832 Advanced 150m", price: 29.90, desc: "0.28mm · 27kg · 8 brins + 1 Gore Performance", badge: "Promo", emoji: "🧵", stock: 30 },
  ],
  "ligne-nylon": [
    { id: 18, name: "Nylon Mitchell Big Mer 500m", price: 18.90, desc: "0.35mm · 12.8kg · Résistance aux UV · Bleu", badge: null, emoji: "🧵", stock: 40 },
    { id: 19, name: "Fluorocarbone Seaguar Red Label 50m", price: 24.90, desc: "0.30mm · 9kg · Indice réfraction eau · Discret", badge: "Bestseller", emoji: "🧵", stock: 22 },
  ],
  "ligne-bas": [
    { id: 20, name: "Bas de Ligne Fluorocarbone 50m", price: 19.90, desc: "0.50mm · 18kg · Invisible sous l'eau · Mer", badge: null, emoji: "🧵", stock: 35 },
    { id: 21, name: "Bas de Ligne Câble Acier 5m", price: 12.90, desc: "7kg · Anti-coupure dents · Gainé nylon · 7x7", badge: null, emoji: "🧵", stock: 20 },
    { id: 22, name: "Bas de Ligne Big Game 100lb", price: 34.90, desc: "100lb · Monofilament premium · Thon & Makaire", badge: "Nouveau", emoji: "🧵", stock: 10 },
  ],
  "leurre-souple": [
    { id: 23, name: "Shad Mer 14cm – Pack x5", price: 16.90, desc: "14cm · Silicone souple · Bar & Limon · 5 couleurs", badge: "Bestseller", emoji: "🐟", stock: 30 },
    { id: 24, name: "Leurre Poulpe Naturel 15cm", price: 9.90, desc: "15cm · Imitation réaliste · Couleur naturelle", badge: null, emoji: "🐟", stock: 25 },
    { id: 25, name: "Curly Tail Mer 10cm x8", price: 12.90, desc: "10cm · Action vibrante · Idéal maquereau & lieu", badge: null, emoji: "🐟", stock: 40 },
  ],
  "leurre-traine": [
    { id: 26, name: "Rapala CD Magnum 18cm", price: 28.90, desc: "18cm · 70g · Profondeur 7-9m · Fini chrome", badge: "Bestseller", emoji: "🐟", stock: 12 },
    { id: 27, name: "Yo-Zuri Crystal Minnow 130mm", price: 22.90, desc: "130mm · 26g · Action nageur coulant · Phosphorescent", badge: null, emoji: "🐟", stock: 8 },
    { id: 28, name: "Feather Traîne Thon 25cm", price: 19.90, desc: "25cm · Plume naturelle · Couleurs vives · Swivel inclus", badge: "Promo", emoji: "🐟", stock: 20 },
  ],
  "leurre-biggame": [
    { id: 29, name: "Leurre Tête Plombée Big Game 300g", price: 34.90, desc: "300g · Jupe silicone · Thon rouge & makaire", badge: "Nouveau", emoji: "🐟", stock: 6 },
    { id: 30, name: "Stick Bait Popper 200mm 120g", price: 49.90, desc: "200mm · 120g · Balsa premium · Finition époxy", badge: null, emoji: "🐟", stock: 4 },
    { id: 31, name: "Daisy Chain Thon 1.5m", price: 59.90, desc: "1.5m · 6 leurres + attracteur · Ligne 300lb", badge: "Bestseller", emoji: "🐟", stock: 5 },
  ],
  "leurre-dur": [
    { id: 32, name: "Popper Surface 110mm 28g", price: 26.90, desc: "110mm · 28g · Bar & Bonite · Anneau renforcé", badge: "Bestseller", emoji: "🐟", stock: 10 },
    { id: 33, name: "Jig Plombé 80g Chartreuse", price: 14.90, desc: "80g · Finition holographique · Hameçon assist inclus", badge: null, emoji: "🐟", stock: 20 },
    { id: 34, name: "Stickbait Coulant 180mm 65g", price: 39.90, desc: "180mm · 65g · Bois de paulownia · Finition epoxy", badge: "Nouveau", emoji: "🐟", stock: 7 },
  ],
  "acc-hamecons": [
    { id: 35, name: "Hameçons Texan Owner 4/0 x10", price: 8.90, desc: "Taille 4/0 · Acier carbone · Weedless · Mer", badge: null, emoji: "🪝", stock: 50 },
    { id: 36, name: "Plombs Olive Bombette 100g x5", price: 6.90, desc: "100g · Plomb certifié · Anti-accroche · Fond rocheux", badge: null, emoji: "🪝", stock: 40 },
    { id: 37, name: "Assist Hook Double 8/0 x5", price: 14.90, desc: "8/0 · Tresse Kevlar 300lb · Jigging lourd", badge: "Bestseller", emoji: "🪝", stock: 25 },
  ],
  "acc-vetements": [
    { id: 38, name: "Veste Imperméable Mer 3 couches", price: 149.00, desc: "Membrane GORE-TEX · Fermetures YKK · Réfléchissant", badge: "Nouveau", emoji: "🦺", stock: 8 },
    { id: 39, name: "Salopette de Mer Étanche", price: 129.00, desc: "Néoprène 4mm · Bretelles réglables · Genouillères", badge: null, emoji: "🦺", stock: 6 },
    { id: 40, name: "Chaussures Bateau Sperry Top-Sider", price: 89.90, desc: "Semelle antidérapante · Cuir traité · Unisexe", badge: null, emoji: "👟", stock: 10 },
  ],
  "acc-outillage": [
    { id: 41, name: "Pince à Dégorger Pro Inox 25cm", price: 19.90, desc: "Inox 316L · Anti-corrosion · Mâchoires cranté", badge: null, emoji: "🔧", stock: 30 },
    { id: 42, name: "Balance Numérique Étanche 50kg", price: 34.90, desc: "50kg max · IPX6 · Crochet inox · Affichage LCD", badge: "Bestseller", emoji: "⚖️", stock: 15 },
    { id: 43, name: "Couteau à Filet Ceramic 22cm", price: 44.90, desc: "Lame céramique 15cm · Manche caoutchouc · Gaine incluse", badge: null, emoji: "🔪", stock: 12 },
  ],
  "acc-glacieres": [
    { id: 44, name: "Glacière Isotherme 50L Marine", price: 89.90, desc: "50L · Paroi 5cm · Rotomoulée · UV résistant", badge: "Nouveau", emoji: "🧊", stock: 7 },
    { id: 45, name: "Vivier de Pêche 30L Aération", price: 59.90, desc: "30L · Pompe aération incluse · Flottant · Anse inox", badge: null, emoji: "🐠", stock: 9 },
  ],
  "bat-gps": [
    { id: 46, name: "GPS Sondeur Lowrance Hook Reveal 7", price: 449.00, desc: "7 pouces · Cartes C-MAP · CHIRP · HDI Transducteur", badge: "Nouveau", emoji: "📡", stock: 4 },
    { id: 47, name: "Sondeur Portable Deeper Pro+", price: 249.00, desc: "Wi-Fi · App iOS/Android · Profondeur 80m · GPS", badge: "Bestseller", emoji: "📡", stock: 6 },
  ],
  "bat-ancres": [
    { id: 48, name: "Ancre Delta Inox 10kg", price: 119.00, desc: "10kg · Inox 316 · Toutes fonds · Jusqu'à 12m bateau", badge: null, emoji: "⚓", stock: 5 },
    { id: 49, name: "Dérouleur Mouillage 15m Chaîne", price: 89.00, desc: "15m · 8mm · Galvanisée à chaud · Maillon rapide", badge: null, emoji: "⚓", stock: 8 },
  ],
  "bat-securite": [
    { id: 50, name: "Gilet de Sauvetage Gonflable 150N", price: 149.00, desc: "150N · Auto-gonflant · Harnais intégré · Norme CE", badge: "Bestseller", emoji: "🛟", stock: 10 },
    { id: 51, name: "Kit Sécurité Mer Complet", price: 89.90, desc: "Fusées 3x · Corne · Torche étanche · Couteau lame repliable", badge: null, emoji: "⛑️", stock: 7 },
  ],
};

export default function App() {
  const [activePage, setActivePage] = useState("accueil");
  const [activeSubPage, setActiveSubPage] = useState(null);
  const [openNav, setOpenNav] = useState(null);
  const [cart, setCart] = useState([]);
  const [showCart, setShowCart] = useState(false);
  const [addedId, setAddedId] = useState(null);

  const addToCart = (product) => {
    setCart(prev => {
      const ex = prev.find(i => i.id === product.id);
      if (ex) return prev.map(i => i.id === product.id ? { ...i, qty: i.qty + 1 } : i);
      return [...prev, { ...product, qty: 1 }];
    });
    setAddedId(product.id);
    setTimeout(() => setAddedId(null), 900);
  };
  const removeFromCart = (id) => setCart(p => p.filter(i => i.id !== id));
  const updateQty = (id, d) => setCart(p => p.map(i => i.id === id ? { ...i, qty: Math.max(1, i.qty + d) } : i));
  const cartCount = cart.reduce((s, i) => s + i.qty, 0);
  const cartTotal = cart.reduce((s, i) => s + i.price * i.qty, 0);

  const navigate = (pageId, subId = null) => {
    setActivePage(pageId);
    setActiveSubPage(subId);
    setOpenNav(null);
  };

  const currentNav = NAV.find(n => n.id === activePage);
  const products = activeSubPage ? PRODUCTS[activeSubPage] || [] : [];

  const badgeColor = (b) => {
    if (b === "Promo") return { bg: "#4a1010", color: "#ff9999" };
    if (b === "Nouveau") return { bg: "#0d3320", color: "#7fd4a0" };
    if (b === "Bestseller") return { bg: "#2a2000", color: "#f0c040" };
    return { bg: "#222", color: "#aaa" };
  };

  return (
    <div style={{ minHeight: "100vh", background: "#06111f", fontFamily: "'Palatino Linotype', 'Book Antiqua', Georgia, serif", color: "#d8e8f0" }}>

      {/* HEADER */}
      <header style={{ background: "rgba(4,10,20,0.97)", borderBottom: "1px solid rgba(100,180,220,0.15)", position: "sticky", top: 0, zIndex: 200, backdropFilter: "blur(12px)" }}>
        <div style={{ background: "rgba(0,80,140,0.3)", padding: "6px 2rem", fontSize: 12, color: "#7ab8d8", display: "flex", justifyContent: "space-between", borderBottom: "1px solid rgba(100,180,220,0.1)", flexWrap: "wrap", gap: 4 }}>
          <span>🌊 Livraison gratuite dès 79€ · Spécialiste pêche en mer depuis 1998</span>
          <span>📞 04 91 00 00 00 · Lun–Sam 9h–18h</span>
        </div>
        <div style={{ maxWidth: 1280, margin: "0 auto", padding: "0 1.5rem", display: "flex", alignItems: "center", justifyContent: "space-between", height: 68 }}>
          <div onClick={() => navigate("accueil")} style={{ cursor: "pointer", display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ fontSize: 30 }}>⚓</div>
            <div>
              <div style={{ fontSize: 19, fontWeight: "bold", color: "#5bc8f0", letterSpacing: 3, textTransform: "uppercase" }}>Mer & Pêche</div>
              <div style={{ fontSize: 9, color: "#4a7a9a", letterSpacing: 4, textTransform: "uppercase" }}>Spécialiste Pêche en Mer</div>
            </div>
          </div>

          <nav style={{ display: "flex", gap: 2, alignItems: "center", flexWrap: "wrap" }}>
            {NAV.filter(n => n.id !== "accueil").map(nav => (
              <div key={nav.id} style={{ position: "relative" }}
                onMouseEnter={() => setOpenNav(nav.id)}
                onMouseLeave={() => setOpenNav(null)}
              >
                <button onClick={() => navigate(nav.id, nav.sub[0]?.id)} style={{
                  background: activePage === nav.id ? "rgba(91,200,240,0.12)" : "none",
                  border: activePage === nav.id ? "1px solid rgba(91,200,240,0.3)" : "1px solid transparent",
                  color: activePage === nav.id ? "#5bc8f0" : "#a8c8dc",
                  padding: "6px 10px", borderRadius: 6, cursor: "pointer", fontSize: 12, fontWeight: activePage === nav.id ? "bold" : "normal",
                  display: "flex", alignItems: "center", gap: 4, transition: "all 0.2s", whiteSpace: "nowrap"
                }}>
                  {nav.icon} {nav.label} {nav.sub.length > 0 && <span style={{ fontSize: 8, opacity: 0.6 }}>▼</span>}
                </button>
                {openNav === nav.id && nav.sub.length > 0 && (
                  <div style={{
                    position: "absolute", top: "100%", left: 0, background: "#07182e",
                    border: "1px solid rgba(91,200,240,0.2)", borderRadius: 10, padding: 8, minWidth: 200,
                    boxShadow: "0 20px 60px rgba(0,0,0,0.8)", zIndex: 300
                  }}>
                    {nav.sub.map(s => (
                      <button key={s.id} onClick={() => navigate(nav.id, s.id)} style={{
                        display: "block", width: "100%", textAlign: "left", padding: "9px 14px",
                        background: activeSubPage === s.id ? "rgba(91,200,240,0.1)" : "none",
                        border: "none", color: activeSubPage === s.id ? "#5bc8f0" : "#a8c8dc",
                        borderRadius: 6, cursor: "pointer", fontSize: 13, transition: "all 0.15s"
                      }}
                        onMouseEnter={e => e.target.style.background = "rgba(91,200,240,0.08)"}
                        onMouseLeave={e => e.target.style.background = activeSubPage === s.id ? "rgba(91,200,240,0.1)" : "none"}
                      >
                        → {s.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </nav>

          <button onClick={() => setShowCart(true)} style={{
            background: cartCount > 0 ? "rgba(91,200,240,0.15)" : "rgba(255,255,255,0.04)",
            border: `1px solid ${cartCount > 0 ? "#5bc8f0" : "rgba(91,200,240,0.2)"}`,
            color: "#5bc8f0", borderRadius: 30, padding: "7px 16px", cursor: "pointer",
            fontSize: 13, display: "flex", alignItems: "center", gap: 7, transition: "all 0.2s", whiteSpace: "nowrap"
          }}>
            🛒 Panier
            {cartCount > 0 && <span style={{ background: "#5bc8f0", color: "#06111f", borderRadius: "50%", width: 20, height: 20, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: "bold" }}>{cartCount}</span>}
          </button>
        </div>
      </header>

      {/* PAGE ACCUEIL */}
      {activePage === "accueil" && (
        <div>
          <style>{`
            @keyframes fadeUp { from{opacity:0;transform:translateY(30px)} to{opacity:1;transform:translateY(0)} }
            @keyframes wave0 { 0%,100%{transform:translateX(-5%)} 50%{transform:translateX(5%)} }
            @keyframes wave1 { 0%,100%{transform:translateX(5%)} 50%{transform:translateX(-5%)} }
          `}</style>
          <div style={{
            minHeight: "86vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
            background: "linear-gradient(170deg, #050f1e 0%, #061828 40%, #04101a 100%)",
            position: "relative", overflow: "hidden", textAlign: "center", padding: "4rem 2rem"
          }}>
            {[...Array(5)].map((_, i) => (
              <div key={i} style={{
                position: "absolute", bottom: `${i * 70}px`, left: "-10%", right: "-10%", height: 2,
                background: `rgba(91,200,240,${0.02 + i * 0.01})`,
                animation: `wave${i % 2} ${4 + i}s ease-in-out infinite`
              }} />
            ))}
            <div style={{ animation: "fadeUp 0.8s ease forwards", position: "relative", zIndex: 1 }}>
              <div style={{ fontSize: 13, color: "#4a9ab8", letterSpacing: 6, textTransform: "uppercase", marginBottom: 20 }}>⚓ Depuis 1998 · Spécialiste Mer ⚓</div>
              <h1 style={{ fontSize: "clamp(2.2rem, 6vw, 4.5rem)", margin: 0, lineHeight: 1.05, color: "#d8e8f0" }}>
                La Pêche en Mer<br />
                <span style={{ color: "#5bc8f0", fontStyle: "italic" }}>comme une passion</span>
              </h1>
              <p style={{ color: "#5a8aa0", fontSize: 17, maxWidth: 540, margin: "1.5rem auto", lineHeight: 1.7 }}>
                Matériel expert sélectionné par des pêcheurs passionnés — du surf-casting au big game, nous équipons vos aventures en mer.
              </p>
              <div style={{ display: "flex", gap: 16, justifyContent: "center", flexWrap: "wrap", marginTop: "2rem" }}>
                <button onClick={() => navigate("cannes", "cannes-bateau")} style={{
                  background: "#5bc8f0", color: "#06111f", border: "none", padding: "13px 28px",
                  borderRadius: 30, fontSize: 15, fontWeight: "bold", cursor: "pointer", letterSpacing: 1
                }}>Voir les Cannes 🎣</button>
                <button onClick={() => navigate("leurres", "leurre-souple")} style={{
                  background: "transparent", color: "#5bc8f0", border: "1px solid #5bc8f0", padding: "13px 28px",
                  borderRadius: 30, fontSize: 15, cursor: "pointer", letterSpacing: 1
                }}>Nos Leurres 🐟</button>
              </div>
            </div>
          </div>

          <div style={{ maxWidth: 1280, margin: "0 auto", padding: "4rem 2rem" }}>
            <div style={{ textAlign: "center", marginBottom: "2.5rem" }}>
              <div style={{ color: "#4a9ab8", letterSpacing: 4, fontSize: 11, textTransform: "uppercase", marginBottom: 10 }}>Notre Catalogue</div>
              <h2 style={{ fontSize: "2rem", color: "#d8e8f0", margin: 0 }}>Explorez nos Univers</h2>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: "1rem" }}>
              {NAV.filter(n => n.id !== "accueil").map(nav => (
                <div key={nav.id} onClick={() => navigate(nav.id, nav.sub[0]?.id)}
                  style={{
                    background: "rgba(91,200,240,0.04)", border: "1px solid rgba(91,200,240,0.12)",
                    borderRadius: 14, padding: "1.6rem 1.2rem", cursor: "pointer", transition: "all 0.25s", textAlign: "center"
                  }}
                  onMouseEnter={e => { e.currentTarget.style.background = "rgba(91,200,240,0.1)"; e.currentTarget.style.borderColor = "rgba(91,200,240,0.4)"; e.currentTarget.style.transform = "translateY(-4px)"; }}
                  onMouseLeave={e => { e.currentTarget.style.background = "rgba(91,200,240,0.04)"; e.currentTarget.style.borderColor = "rgba(91,200,240,0.12)"; e.currentTarget.style.transform = "translateY(0)"; }}
                >
                  <div style={{ fontSize: 38, marginBottom: 10 }}>{nav.icon}</div>
                  <div style={{ color: "#d8e8f0", fontSize: 15, fontWeight: "bold", marginBottom: 6 }}>{nav.label}</div>
                  <div style={{ color: "#4a8aa0", fontSize: 11, lineHeight: 1.5 }}>{nav.sub.length > 0 ? nav.sub.map(s => s.label).join(" · ") : "Voir les produits"}</div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ borderTop: "1px solid rgba(91,200,240,0.1)", borderBottom: "1px solid rgba(91,200,240,0.1)", background: "rgba(0,40,80,0.2)", padding: "2rem" }}>
            <div style={{ maxWidth: 1280, margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: "1.5rem", textAlign: "center" }}>
              {[["🚢", "Livraison express", "Expédition en 24h"], ["🔒", "Paiement sécurisé", "3DS & SSL"], ["🔄", "Retours 30 jours", "Satisfait ou remboursé"], ["📞", "Conseil expert", "Pêcheurs passionnés"]].map(([icon, title, sub]) => (
                <div key={title}>
                  <div style={{ fontSize: 26, marginBottom: 6 }}>{icon}</div>
                  <div style={{ color: "#d8e8f0", fontWeight: "bold", fontSize: 13 }}>{title}</div>
                  <div style={{ color: "#4a7a9a", fontSize: 12, marginTop: 3 }}>{sub}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* PAGE SOUS-CATEGORIE */}
      {activePage !== "accueil" && (
        <div style={{ maxWidth: 1280, margin: "0 auto", padding: "2rem 1.5rem" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: "1.5rem", fontSize: 13, color: "#4a8aa0", flexWrap: "wrap" }}>
            <span onClick={() => navigate("accueil")} style={{ cursor: "pointer" }}>Accueil</span>
            <span>›</span>
            <span style={{ color: "#7ab8d8" }}>{currentNav?.label}</span>
            {activeSubPage && currentNav?.sub.find(s => s.id === activeSubPage) && (
              <><span>›</span><span style={{ color: "#5bc8f0" }}>{currentNav.sub.find(s => s.id === activeSubPage).label}</span></>
            )}
          </div>

          <div style={{ display: "flex", gap: "1.5rem", alignItems: "flex-start", flexWrap: "wrap" }}>
            {currentNav?.sub.length > 0 && (
              <div style={{ minWidth: 185, background: "rgba(91,200,240,0.03)", border: "1px solid rgba(91,200,240,0.12)", borderRadius: 14, padding: "1rem", flexShrink: 0 }}>
                <div style={{ fontSize: 11, color: "#4a8aa0", letterSpacing: 3, textTransform: "uppercase", marginBottom: 10, padding: "0 6px" }}>
                  {currentNav.icon} {currentNav.label}
                </div>
                {currentNav.sub.map(s => (
                  <button key={s.id} onClick={() => navigate(activePage, s.id)} style={{
                    display: "block", width: "100%", textAlign: "left", padding: "10px 12px",
                    background: activeSubPage === s.id ? "rgba(91,200,240,0.12)" : "none",
                    border: activeSubPage === s.id ? "1px solid rgba(91,200,240,0.3)" : "1px solid transparent",
                    color: activeSubPage === s.id ? "#5bc8f0" : "#a8c8dc",
                    borderRadius: 8, cursor: "pointer", fontSize: 13, marginBottom: 4, transition: "all 0.15s"
                  }}>
                    {activeSubPage === s.id ? "▶" : "›"} {s.label}
                  </button>
                ))}
              </div>
            )}

            <div style={{ flex: 1, minWidth: 0 }}>
              {activeSubPage && (
                <>
                  <h2 style={{ color: "#d8e8f0", margin: "0 0 1.5rem", fontSize: 22 }}>
                    {currentNav?.sub.find(s => s.id === activeSubPage)?.label}
                    <span style={{ fontSize: 13, color: "#4a8aa0", marginLeft: 12 }}>{products.length} produits</span>
                  </h2>
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: "1.1rem" }}>
                    {products.map(p => {
                      const bc = badgeColor(p.badge);
                      return (
                        <div key={p.id}
                          style={{ background: "rgba(91,200,240,0.04)", border: "1px solid rgba(91,200,240,0.12)", borderRadius: 14, overflow: "hidden", transition: "all 0.2s", position: "relative" }}
                          onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-4px)"; e.currentTarget.style.borderColor = "rgba(91,200,240,0.4)"; }}
                          onMouseLeave={e => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.borderColor = "rgba(91,200,240,0.12)"; }}
                        >
                          {p.badge && (
                            <div style={{ position: "absolute", top: 10, right: 10, background: bc.bg, color: bc.color, fontSize: 10, padding: "3px 10px", borderRadius: 20, fontWeight: "bold", letterSpacing: 1 }}>
                              {p.badge}
                            </div>
                          )}
                          <div style={{ height: 120, background: "linear-gradient(135deg, rgba(5,30,60,0.8), rgba(0,50,80,0.4))", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 48, borderBottom: "1px solid rgba(91,200,240,0.08)" }}>
                            {p.emoji}
                          </div>
                          <div style={{ padding: "1.1rem" }}>
                            <div style={{ fontSize: 14, color: "#d8e8f0", fontWeight: "bold", marginBottom: 5, lineHeight: 1.3 }}>{p.name}</div>
                            <div style={{ fontSize: 12, color: "#5a8aa0", marginBottom: 12, lineHeight: 1.5 }}>{p.desc}</div>
                            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                              <div>
                                <span style={{ fontSize: 19, color: "#5bc8f0", fontWeight: "bold" }}>{p.price.toFixed(2)} €</span>
                                <div style={{ fontSize: 11, color: "#2a5a70", marginTop: 2 }}>En stock ({p.stock})</div>
                              </div>
                              <button onClick={() => addToCart(p)} style={{
                                background: addedId === p.id ? "rgba(91,200,100,0.2)" : "rgba(91,200,240,0.1)",
                                border: `1px solid ${addedId === p.id ? "#5bc870" : "#5bc8f0"}`,
                                color: addedId === p.id ? "#7fd4a0" : "#5bc8f0",
                                borderRadius: 10, padding: "8px 14px", cursor: "pointer", fontSize: 17, transition: "all 0.2s"
                              }}>
                                {addedId === p.id ? "✓" : "+"}
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </>
              )}
              {!activeSubPage && (
                <div style={{ textAlign: "center", padding: "4rem", color: "#4a8aa0" }}>
                  <div style={{ fontSize: 48, marginBottom: 12 }}>{currentNav?.icon}</div>
                  <div style={{ fontSize: 18, color: "#7ab8d8" }}>Choisissez une sous-catégorie</div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* PANIER */}
      {showCart && (
        <div style={{ position: "fixed", inset: 0, zIndex: 500, background: "rgba(0,0,0,0.75)", backdropFilter: "blur(6px)" }}
          onClick={() => setShowCart(false)}>
          <div onClick={e => e.stopPropagation()} style={{
            position: "absolute", right: 0, top: 0, bottom: 0, width: "min(420px,100vw)",
            background: "#07182e", borderLeft: "1px solid rgba(91,200,240,0.2)",
            display: "flex", flexDirection: "column", padding: "1.5rem", overflowY: "auto"
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1.5rem" }}>
              <h2 style={{ margin: 0, color: "#5bc8f0", fontSize: 20 }}>🛒 Mon Panier</h2>
              <button onClick={() => setShowCart(false)} style={{ background: "none", border: "none", color: "#5a8aa0", cursor: "pointer", fontSize: 22 }}>✕</button>
            </div>
            <div style={{ flex: 1 }}>
              {cart.length === 0 ? (
                <div style={{ textAlign: "center", color: "#4a8aa0", marginTop: "3rem" }}>
                  <div style={{ fontSize: 48 }}>⚓</div>
                  <p style={{ marginTop: 12 }}>Votre panier est vide</p>
                </div>
              ) : cart.map(item => (
                <div key={item.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 0", borderBottom: "1px solid rgba(91,200,240,0.08)" }}>
                  <span style={{ fontSize: 24 }}>{item.emoji}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13, color: "#d8e8f0", lineHeight: 1.3 }}>{item.name}</div>
                    <div style={{ fontSize: 13, color: "#5bc8f0", marginTop: 2 }}>{item.price.toFixed(2)} €</div>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                    <button onClick={() => updateQty(item.id, -1)} style={{ background: "rgba(255,255,255,0.07)", border: "none", color: "#d8e8f0", borderRadius: 5, width: 24, height: 24, cursor: "pointer" }}>-</button>
                    <span style={{ color: "#d8e8f0", fontSize: 13, minWidth: 16, textAlign: "center" }}>{item.qty}</span>
                    <button onClick={() => updateQty(item.id, 1)} style={{ background: "rgba(255,255,255,0.07)", border: "none", color: "#d8e8f0", borderRadius: 5, width: 24, height: 24, cursor: "pointer" }}>+</button>
                  </div>
                  <button onClick={() => removeFromCart(item.id)} style={{ background: "none", border: "none", color: "#6a3a3a", cursor: "pointer", fontSize: 14 }}>🗑</button>
                </div>
              ))}
            </div>
            {cart.length > 0 && (
              <div style={{ borderTop: "1px solid rgba(91,200,240,0.15)", paddingTop: "1.5rem", marginTop: "1rem" }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "1rem" }}>
                  <span style={{ color: "#5a8aa0" }}>Total TTC</span>
                  <span style={{ color: "#5bc8f0", fontSize: 22, fontWeight: "bold" }}>{cartTotal.toFixed(2)} €</span>
                </div>
                <button style={{ width: "100%", padding: 13, background: "linear-gradient(135deg, #5bc8f0, #2a88b8)", border: "none", borderRadius: 12, color: "#06111f", fontSize: 15, fontWeight: "bold", cursor: "pointer", letterSpacing: 1 }}>
                  Valider la commande →
                </button>
                <div style={{ textAlign: "center", fontSize: 11, color: "#3a6a80", marginTop: 10 }}>🔒 Paiement 100% sécurisé</div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* FOOTER */}
      <footer style={{ marginTop: "4rem", borderTop: "1px solid rgba(91,200,240,0.1)", background: "#04101a", padding: "3rem 2rem" }}>
        <div style={{ maxWidth: 1280, margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: "2rem" }}>
          <div>
            <div style={{ fontSize: 17, color: "#5bc8f0", fontWeight: "bold", marginBottom: 8 }}>⚓ Mer & Pêche</div>
            <p style={{ color: "#4a7a9a", fontSize: 13, lineHeight: 1.7, margin: 0 }}>Votre spécialiste de la pêche en mer depuis 1998. Conseil expert, matériel premium sélectionné.</p>
          </div>
          <div>
            <div style={{ color: "#7ab8d8", fontSize: 12, fontWeight: "bold", marginBottom: 10, letterSpacing: 2, textTransform: "uppercase" }}>Catalogue</div>
            {NAV.filter(n => n.id !== "accueil").map(n => (
              <div key={n.id} onClick={() => navigate(n.id, n.sub[0]?.id)} style={{ color: "#4a7a9a", fontSize: 13, marginBottom: 6, cursor: "pointer" }}>{n.icon} {n.label}</div>
            ))}
          </div>
          <div>
            <div style={{ color: "#7ab8d8", fontSize: 12, fontWeight: "bold", marginBottom: 10, letterSpacing: 2, textTransform: "uppercase" }}>Informations</div>
            {["Livraison & Retours", "Paiement sécurisé", "CGV", "Mentions légales", "Contact"].map(l => (
              <div key={l} style={{ color: "#4a7a9a", fontSize: 13, marginBottom: 6, cursor: "pointer" }}>{l}</div>
            ))}
          </div>
          <div>
            <div style={{ color: "#7ab8d8", fontSize: 12, fontWeight: "bold", marginBottom: 10, letterSpacing: 2, textTransform: "uppercase" }}>Contact</div>
            <div style={{ color: "#4a7a9a", fontSize: 13, lineHeight: 2 }}>
              📞 04 91 00 00 00<br />
              ✉️ contact@mer-et-peche.fr<br />
              📍 Marseille, France<br />
              🕐 Lun–Sam 9h–18h
            </div>
          </div>
        </div>
        <div style={{ textAlign: "center", marginTop: "2rem", paddingTop: "1.5rem", borderTop: "1px solid rgba(91,200,240,0.08)", color: "#2a5a70", fontSize: 12 }}>
          © 2025 Mer & Pêche · Tous droits réservés · Spécialiste Pêche en Mer
        </div>
      </footer>
    </div>
  );
}
