# 🎣 Mer & Pêche – Boutique en ligne

## 🚀 GUIDE DE MISE EN LIGNE GRATUITE (Vercel)

Suivez ces étapes dans l'ordre. Ça prend environ 15 minutes !

---

## ÉTAPE 1 – Créer un compte GitHub (gratuit)

1. Allez sur **https://github.com**
2. Cliquez sur **"Sign up"**
3. Créez votre compte avec votre email

---

## ÉTAPE 2 – Mettre le projet sur GitHub

1. Une fois connecté sur GitHub, cliquez sur le **"+"** en haut à droite
2. Cliquez sur **"New repository"**
3. Nom du projet : `mer-et-peche`
4. Laissez en **"Public"**
5. Cliquez sur **"Create repository"**

Ensuite, sur la page qui s'affiche, cliquez sur **"uploading an existing file"**
et glissez-déposez tous les fichiers de ce dossier ZIP.

---

## ÉTAPE 3 – Créer un compte Vercel (gratuit)

1. Allez sur **https://vercel.com**
2. Cliquez sur **"Sign Up"**
3. Choisissez **"Continue with GitHub"** (connectez-vous avec votre compte GitHub)

---

## ÉTAPE 4 – Déployer votre site

1. Sur Vercel, cliquez sur **"Add New Project"**
2. Vous verrez votre projet `mer-et-peche` dans la liste
3. Cliquez sur **"Import"**
4. Laissez tous les paramètres par défaut
5. Cliquez sur **"Deploy"**

⏳ Attendez 2-3 minutes...

✅ **Votre site est en ligne !** Vercel vous donnera une adresse du type :
`mer-et-peche.vercel.app`

---

## 🔄 Comment modifier votre site ensuite ?

Chaque fois que vous modifiez un fichier sur GitHub,
Vercel met automatiquement votre site à jour.

---

## 📞 Besoin d'aide ?

Revenez sur Claude et dites-lui ce que vous souhaitez modifier !
